import { useEffect, useState, useRef } from 'react'
import Header from '../../components/Header'
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
const supabase = createClient(supabaseUrl, supabaseAnon)

export default function ChatRoom({}) {
  const [messages, setMessages] = useState([])
  const [text, setText] = useState('')
  const room = 'global' // simple single room for demo
  const ref = useRef(null)

  useEffect(() => {
    let mounted = true
    async function load() {
      const { data } = await supabase.from('messages').select('*').order('created_at', { ascending: true }).limit(200)
      if (!mounted) return
      setMessages(data || [])
    }
    load()

    const subscription = supabase.channel('public:messages').on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, payload => {
      setMessages(prev => [...prev, payload.new])
    }).subscribe()

    return () => {
      mounted = false
      subscription.unsubscribe()
    }
  }, [])

  async function send() {
    if (!text.trim()) return
    await supabase.from('messages').insert([{ room, text }])
    setText('')
  }

  return (
    <div className='min-h-screen bg-gray-900 text-white'>
      <Header />
      <main className='max-w-3xl mx-auto p-6'>
        <h2 className='text-2xl font-bold mb-4'>Chat (sala: {room})</h2>
        <div ref={ref} className='bg-gray-800 p-4 rounded h-64 overflow-y-auto mb-4'>
          {messages.map(m => (
            <div key={m.id} className='mb-2'>
              <div className='text-sm text-gray-400'>{new Date(m.created_at).toLocaleString()}</div>
              <div className='bg-gray-700 p-2 rounded'>{m.text}</div>
            </div>
          ))}
        </div>
        <div className='flex gap-2'>
          <input className='flex-1 px-3 py-2 rounded bg-gray-800' value={text} onChange={e => setText(e.target.value)} placeholder='Escreva uma mensagem...' />
          <button className='px-4 py-2 bg-indigo-600 rounded' onClick={send}>Enviar</button>
        </div>
      </main>
    </div>
  )
}
