import Header from '../components/Header'
import { profiles } from '../lib/mockdata'

export default function Profiles() {
  return (
    <div className='min-h-screen bg-gray-900 text-white'>
      <Header />
      <main className='max-w-4xl mx-auto p-6'>
        <h2 className='text-2xl font-bold mb-4'>Perfis</h2>
        <div className='grid md:grid-cols-2 gap-4'>
          {profiles.map(p => (
            <div key={p.id} className='bg-gray-800 p-4 rounded'>
              <div className='flex items-center gap-4'>
                <div className='w-14 h-14 rounded-full bg-gradient-to-br from-yellow-400 to-indigo-600 flex items-center justify-center font-bold'>{p.nick[0]}</div>
                <div>
                  <div className='font-bold'>{p.nick} <span className='text-sm text-gray-400'>• {p.age}</span></div>
                  <div className='text-xs text-gray-400'>{p.city} • {p.games.join(', ')}</div>
                </div>
              </div>
              <p className='text-gray-300 mt-2'>{p.bio}</p>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}
