import Link from 'next/link'
import Header from '../components/Header'

export default function Home() {
  return (
    <div className='min-h-screen bg-gray-900 text-white'>
      <Header />
      <main className='max-w-4xl mx-auto p-6'>
        <h1 className='text-4xl font-bold mb-4'>GamerMatch (Realtime Demo)</h1>
        <p className='mb-6 text-gray-300'>Protótipo com autenticação Supabase e chat em tempo real (setup necessário).</p>
        <div className='flex gap-3'>
          <Link href='/profiles'><a className='px-4 py-2 bg-indigo-600 rounded'>Ver Perfis</a></Link>
          <Link href='/chat/1'><a className='px-4 py-2 border rounded'>Entrar no Chat (demo)</a></Link>
        </div>
      </main>
    </div>
  )
}
